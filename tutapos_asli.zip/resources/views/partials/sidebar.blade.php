<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="{{asset('/img/synergydatatrust.com.png')}}" class="img-circle" alt="User Image" />
            </div>
            <div class="pull-left info">
                <p>{{ Auth::user()->name }}</p>
                <!-- Status -->
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>

           

        <!-- Sidebar Menu di hilangkan searchingnya -->
        <ul class="sidebar-menu"> 
            <!-- Optionally, you can add icons to the links -->
            <li><a href="{{ url('home') }}"><i class='fa fa-home'></i> <span>Home</span></a></li>
            
            @if (Auth::check())
                        <li><a href="{{ url('/sales') }}"><i class="fa fa-cart-plus" aria-hidden="true"></i <span>{{trans('menu.sales')}}</span></a></li>
                        <li><a href="{{ url('/customers') }}"><i class="fa fa-users" aria-hidden="true"></i> <span>{{trans('menu.customers')}}</span></a></li>
                        <li><a href="{{ url('/items') }}"><i class="fa fa-tasks" aria-hidden="true"></i> <span>{{trans('menu.items')}}</span></a></li>
                        <li><a href="{{ url('/item-kits') }}"><i class="fa fa-bitbucket" aria-hidden="true"></i> <span>{{trans('menu.item_kits')}}</span></a></li>
                        <li><a href="{{ url('/suppliers') }}"><i class="fa fa-github-alt" aria-hidden="true"></i> <span>{{trans('menu.suppliers')}}</span></a></li>
                        <li><a href="{{ url('/receivings') }}"><i class="fa fa-buysellads" aria-hidden="true"></i> <span>{{trans('menu.receivings')}}</span></a></li>
                        

                        <li class="treeview">
                            <a href="#"><i class='fa fa-cog fa-fw'></i> <span>Maintenace</span> <i class="fa fa-angle-left pull-right"></i></a>
                             <ul class="treeview-menu">
                            {{trans('menu.reports')}}  
                              <li><a href="{{ url('/reports/receivings') }}">{{trans('menu.receivings_report')}}</a></li>
                              <li><a href="{{ url('/reports/sales') }}">{{trans('menu.sales_report')}}</a></li>
                              <li><a href="{{ url('/employees') }}">{{trans('menu.employees')}}</a></li>
                            </ul>
                        </li>
                     @endif
 
            


        </ul><!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>
