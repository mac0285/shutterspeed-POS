 
      <div class="container" align="center">
        <p class="text-muted">&copy; <a href="https://synergydatatrust.com">SynergyDataTrust.Com</a> v0.1.by 
        <a href="http://116.206.196.14"><i class="fa fa-balance-scale"></i></a>.
        </p>
      </div>
  
	<!-- Scripts -->
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script>