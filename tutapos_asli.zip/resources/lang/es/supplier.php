<?php

return [

    'list_suppliers' => 'Listado de Proveedores',
    'new_supplier' => 'Nuevo Proveedor',
    'company_name' => 'Empresa',
    'name' => 'Nombre',
    'email' => 'Email',
    'phone_number' => 'Teléfono',
    'avatar' => 'Imagen',
    'choose_avatar' => 'Seleccione una imagen:',
    'address' => 'Dirección',
    'city' => 'Ciudad',
    'state' => 'Estado/Provincia',
    'zip' => 'Código Postal',
    'comments' => 'Comentarios',
    'account' => 'Cuenta',
    'submit' => 'Guardar',
    'edit' => 'Editar',
    'delete' => 'Borrar',
    'update_supplier' => 'Guardar',
];
