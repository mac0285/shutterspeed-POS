<?php

return [

	'list_customers'	=> 'Daftar Pelanggan',
	'new_customer' 		=> 'Pelanggan Baru',
	'customer_id'		=> 'ID Pelanggan',
	'name' 				=> 'Nama',
	'email' 			=> 'Email',
	'phone_number' 		=> 'Nomor Telepon',
	'avatar' 			=> 'Foto',
	'choose_avatar'		=> 'Pilih Foto',
	'address'			=> 'Alamat',
	'city'				=> 'Kota',
	'state'				=> 'Provinsi',
	'zip'				=> 'Kode Pos',
	'company_name'		=> 'Nama Perusahaan',
	'account'			=> 'Akun',
	'Submit'			=> 'Submit',
	'edit'	=> 'Ganti',
	'delete' => 'Hapus',
	'update_customer' => 'Ganti Pelanggan',

];
