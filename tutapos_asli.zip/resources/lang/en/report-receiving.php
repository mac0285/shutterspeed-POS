<?php

return [

	'reports' => 'Reports',
	'receivings_report' => 'Receivings Report',
	'grand_total' => 'TOTAL',
	'receiving_id' => 'Receiving ID',
	'date' => 'Date',
	'items_received' => 'Items Received',
	'received_by' => 'Received By',
	'supplied_by' => 'Supplied By',
	'total' => 'Total',
	'payment_type' => 'Payment Type',
	'comments' => 'Comments',
	'detail' => 'Detail',
	'item_id' => 'Item ID',
	'item_name' => 'Item Name:',
	'item_received' => 'Item Received',

];
