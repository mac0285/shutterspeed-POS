<?php

return [

	'dashboard' 			=> 'Dashboard',
	'customers' 			=> 'Customers',
	'employees'				=> 'Employees',
	'items' 				=> 'Items',
	'item_kits' 			=> 'Item Kits',
	'suppliers' 			=> 'Suppliers',
	'receivings' 			=> 'Receivings',
	'sales' 				=> 'Sales',
	'reports' 				=> 'Reports',
	'receivings_report' 	=> 'Receivings Report',
	'sales_report' 			=> 'Sales Report',
	'logout'				=> 'Logout',
	'application_settings' 	=> 'Application Settings'

];
