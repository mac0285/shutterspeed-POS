<?php

return [

	'item_receiving' => 'Items Receiving',
	'search_item' => 'Search Item:',
	'invoice' => 'Invoice',
	'employee' => 'Employee',
	'payment_type' => 'Payment Type',
	'supplier' => 'Supplier',
	'item_id' => 'Item ID',
	'item_name' => 'Item Name',
	'cost' => 'Cost',
	'quantity' => 'Quantity',
	'total' => 'Total',
	'amount_tendered' => 'Amount Tendered',
	'comments' => 'Comments',
	'grand_total' => 'TOTAL:',
	'submit' => 'Finish Receiving',
	//struk
	'receiving_id' => 'Receiving ID',
	'item' => 'Item',
	'price' => 'Price',
	'qty' => 'Qty',
	'print' => 'Print',
	'new_receiving' => 'New Receiving',

];
