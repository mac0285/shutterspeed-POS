<?php

return [

	'list_suppliers'	=> 'List Suppliers',
	'new_supplier'		=> 'New Supplier',
	'company_name' 		=> 'Company Name',
	'name' 	=> 'Name',
	'email' 	=> 'Email',
	'phone_number' => 'Phone Number',
	'avatar'		=> 'Avatar',
	'choose_avatar' => 'Choose Avatar:',
	'address' => 'Address',
	'city' => 'City',
	'state' => 'State',
	'zip' => 'Zip',
	'comments' => 'Comments',
	'account' => 'Account',
	'submit' => 'Submit',
	'edit' => 'Edit',
	'delete' => 'Delete',
	'update_supplier' => 'Update Supplier',

];
