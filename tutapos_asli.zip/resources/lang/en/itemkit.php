<?php

return [

	'item_kits'	=> 'Item Kits',
	'new_item_kit'		=> 'New Item Kit',
	'item_kit_id' 		=> 'Item Kit ID',
	'item_kit_name' 	=> 'Item Kit Name',
	'cost_price' 	=> 'Cost Price',
	'selling_price' => 'Selling Price',
	'item_kit_description'		=> 'Item Kit Description',
	'search_item' => 'Search Item:',
	'description' => 'Description',
	'quantity' => 'Quantity',
	'profit' => 'PROFIT:',
	'item_id' => 'Item ID',
	'item_name' => 'Item Name',
	'submit' => 'Submit Item Kit',


];
